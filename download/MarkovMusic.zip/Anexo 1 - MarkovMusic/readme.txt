El paquete MarkovMusic est� dise�ado para R. Para descargar R se debe
ingresar a la p�gina https://www.r-project.org/

El paquete MarkovMusic depende del paquete XML, el cual est� disponible 
en CRAN. Para instalar el paquete XML puede escribir el comando 
install.packages("XML") en la consola de R.

Para instalar el paquete MarkovMusic puede escribir el comando 
utils:::menuInstallLocal() en la consola y seleccionar el archivo fuente
"MarkovMusic_0.1.0.tar.gz".

Para visualizar los archivos en formato XML producidos por la funci�n
se puede utilizar cualquier software de composici�n musical que soporte
el formato XML. En particular, para el desarrollo del proyecto se utiliz�
MuseScore 2, disponible en la p�gina https://musescore.org/en/download